#ifndef _WIN32
#define HAVE_SYS_TYPES_H 1
#define HAVE_UNISTD_H 1
#define TIME_WITH_SYS_TIME
#define HAVE_STDBOOL_H 1
#define HAVE_GETTIMEOFDAY 1
#define HAVE_ERRNO_H 1
#endif
